<p align="center">
  <img src="https://telegra.ph/file/5a180a318e09d49295c8e.jpg">
</p>

<h4><p align="center"> EMIKO ROBOT </p></h4>

<p align="center">Emiko Robot is a modular bot running on python3 with anime theme and have a lot features.</p>

<p align="center">
<a href="https://t.me/Aikarobot"> <img src="https://img.shields.io/badge/Emiko-Robot-blue?&logo=telegram" alt="Emiko on Telegram" /> </a><br>
<a href="https://python-telegram-bot.org"> <img src="https://img.shields.io/badge/PTB-13.13-white?&style=flat-round&logo=github" alt="Python Telegram Bot" /> </a>
<a href="https://github.com/psf/black"><img alt="Code style: black" src="https://img.shields.io/badge/code%20style-black-000000.svg"></a><br>
<a href="https://docs.telethon.dev"> <img src="https://img.shields.io/badge/Telethon-1.24.0-red?&style=flat-round&logo=github" alt="Telethon" /> </a>
<a href="https://docs.python.org"> <img src="https://img.shields.io/badge/Python-3.10.5-purple?&style=flat-round&logo=python" alt="Python" /> </a><br>
<a href="https://GitHub.com/kennedy-ex/EmikoRobot"> <img src="https://img.shields.io/badge/Maintained-Yash-yellow.svg" alt="Maintenance" /> </a><br>
<a href="https://github.com/kennedy-ex/EmikoRobot/blob/main/LICENSE"> <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License" /> </a>
<a href="https://makeapullrequest.com"> <img src="https://img.shields.io/badge/PRs-Welcome-blue.svg?style=flat-round" alt="PRs" /> </a>
</p>

### TUTORIAL

- First fork this repository.
- Then change the deploy link bellow.
- This step must be doing because mine link is violates the salesforce acceptable use.
- You can just change the name of github on deploy link and done, the repos able to deploy on heroku.
- Full Tutorial - [![Full Tutorial](https://img.shields.io/badge/Watch%20Now-blue)](https://youtu.be/GMaYMYhf_Vk)

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/kennedy-ex/EmikoRobot"> <img 
src="https://img.shields.io/badge/Deploy%20To%20Heroku-red?style=flat&logo=heroku" width="210" height="34.45" /></a></p>


```
This Bot is Created by KennedyProject, If your kanging this without fork at least give a credit to get a smile of my hard work. 
- EmikoRobot
- SaitamaRobot 
- WilliamButcherBot
```

### Support
<p>
<a href="https://t.me/usernot4found"> <img src="https://img.shields.io/badge/Sena-Ex-blue?&logo=telegram" alt="Sena on Telegram" /> </a><br>
<a href="https://t.me/EmikoSupport"> <img src="https://img.shields.io/badge/Support-Chat-blue?&logo=telegram" alt="Support Chat" /> </a><br>
<a href="https://t.me/KennedyProject"> <img src="https://img.shields.io/badge/Update-Channel-blue?&logo=telegram" alt="Update Channel" /> </a><br>
</p>

## Credit 

```
It's useless to give credit because YOU won't care.
```
